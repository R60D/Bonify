# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Bonify_RigidBody",
    "description": "A tool for turning physics simulations into models for source.",
    "author": "R60D",
    "version": (3, 0, 0),
    "blender": (2, 91, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
bonify_rigidbody = {
    "obj_name": [], 
    "temp_length": -1, 
    "temp_bonenames": [], 
    "temp_armature_list": [], 
    "bonify_complete": False, 
    "bake_complete": False, 
    "add_rigidbody": False, 
    "prev_value": 0, 
    "vertex_length": [], 
    "qc_list": [], 
    "mesh_matcher_complete": False, 
    "temp_phys_name": [], 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        for area in bpy.context.screen.areas:
            area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   Bonify_RigidBody
def rigid_detect():
    try:
        bonify_rigidbody["add_rigidbody"] = False
        for_node_7A5C3 = 0
        for_node_index_7A5C3 = 0
        for for_node_index_7A5C3, for_node_7A5C3 in enumerate(bonify_rigidbody["obj_name"]):
            if bpy.data.objects[sn_cast_string(for_node_7A5C3)].rigid_body == None:
                bonify_rigidbody["add_rigidbody"] = True
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function RIGID DETECT")

def bone_child_maker():
    try:
        bpy.ops.object.select_all('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
        for_node_0E123 = 0
        for_node_index_0E123 = 0
        for for_node_index_0E123, for_node_0E123 in enumerate(bonify_rigidbody["temp_armature_list"]):
            for_node_36AB3 = 0
            for_node_index_36AB3 = 0
            for for_node_index_36AB3, for_node_36AB3 in enumerate(bpy.data.objects[sn_cast_string(for_node_0E123)].pose.bones):
                run_function_on_399B4 = for_node_36AB3.constraints.new(type=sn_cast_enum(r"CHILD_OF", [("CAMERA_SOLVER","Camera Solver",""),("FOLLOW_TRACK","Follow Track",""),("OBJECT_SOLVER","Object Solver",""),("COPY_LOCATION","Copy Location","Copy the location of a target (with an optional offset), so that they move together"),("COPY_ROTATION","Copy Rotation","Copy the rotation of a target (with an optional offset), so that they rotate together"),("COPY_SCALE","Copy Scale","Copy the scale factors of a target (with an optional offset), so that they are scaled by the same amount"),("COPY_TRANSFORMS","Copy Transforms","Copy all the transformations of a target, so that they move together"),("LIMIT_DISTANCE","Limit Distance","Restrict movements to within a certain distance of a target (at the time of constraint evaluation only)"),("LIMIT_LOCATION","Limit Location","Restrict movement along each axis within given ranges"),("LIMIT_ROTATION","Limit Rotation","Restrict rotation along each axis within given ranges"),("LIMIT_SCALE","Limit Scale","Restrict scaling along each axis with given ranges"),("MAINTAIN_VOLUME","Maintain Volume","Compensate for scaling one axis by applying suitable scaling to the other two axes"),("TRANSFORM","Transformation","Use one transform property from target to control another (or same) property on owner"),("TRANSFORM_CACHE","Transform Cache","Look up the transformation matrix from an external file"),("CLAMP_TO","Clamp To","Restrict movements to lie along a curve by remapping location along curve's longest axis"),("DAMPED_TRACK","Damped Track","Point towards a target by performing the smallest rotation necessary"),("IK","Inverse Kinematics","Control a chain of bones by specifying the endpoint target (Bones only)"),("LOCKED_TRACK","Locked Track","Rotate around the specified ('locked') axis to point towards a target"),("SPLINE_IK","Spline IK","Align chain of bones along a curve (Bones only)"),("STRETCH_TO","Stretch To","Stretch along Y-Axis to point towards a target"),("TRACK_TO","Track To","Legacy tracking constraint prone to twisting artifacts"),("ACTION","Action","Use transform property of target to look up pose for owner from an Action"),("ARMATURE","Armature","Apply weight-blended transformation from multiple bones like the Armature modifier"),("CHILD_OF","Child Of","Make target the 'detachable' parent of owner"),("FLOOR","Floor","Use position (and optionally rotation) of target to define a 'wall' or 'floor' that the owner can not cross"),("FOLLOW_PATH","Follow Path","Use to animate an object/bone following a path"),("PIVOT","Pivot","Change pivot point for transforms (buggy)"),("SHRINKWRAP","Shrinkwrap","Restrict movements to surface of target mesh"),]), )
                run_function_on_399B4.target=bpy.data.objects[for_node_36AB3.name]
    except Exception as exc:
        print(str(exc) + " | Error in function Bone child maker")

def store_obj_data():
    try:
        bonify_rigidbody["vertex_length"] = []
        bonify_rigidbody["obj_name"] = []
        bpy.context.scene.frame_current = 0
        for_node_CDD03 = 0
        for_node_index_CDD03 = 0
        for for_node_index_CDD03, for_node_CDD03 in enumerate(bpy.context.selected_objects):
            if for_node_CDD03.type=="MESH":
                bonify_rigidbody["obj_name"].append(for_node_CDD03.name)
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function STORE OBJ DATA")

def deselect_exportables():
    try:
        bpy.data.collections[r"RigidBodyWorld"].vs["export"] = False
        bpy.data.collections[r"Collection"].vs["export"] = False
    except Exception as exc:
        print(str(exc) + " | Error in function DESELECT_EXPORTABLES")

def physics_mesh_gen():
    try:
        bpy.ops.object.duplicate_move('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',OBJECT_OT_duplicate=None,TRANSFORM_OT_translate=None,)
        bpy.context.active_object.name=sn_cast_string(bonify_rigidbody["temp_phys_name"][int((sn_cast_float(len(bonify_rigidbody["temp_phys_name"])) + -1.0))])
        bpy.context.active_object.parent_bone=r""
    except Exception as exc:
        print(str(exc) + " | Error in function physics_mesh_gen")

def object_fix():
    try:
        for_node_E934E = 0
        for_node_index_E934E = 0
        for for_node_index_E934E, for_node_E934E in enumerate(bonify_rigidbody["obj_name"]):
            run_function_on_EA682 = bpy.data.objects[sn_cast_string(for_node_E934E)].select_set(state=bpy.data.objects[sn_cast_string(for_node_E934E)].type=="MESH", view_layer=None, )
        bpy.ops.object.transform_apply('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',location=False,rotation=True,scale=True,properties=True,)
        bpy.ops.object.origin_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',type=sn_cast_enum(r"ORIGIN_CENTER_OF_VOLUME", [("GEOMETRY_ORIGIN","Geometry to Origin","Move object geometry to object origin"),("ORIGIN_GEOMETRY","Origin to Geometry","Calculate the center of geometry based on the current pivot point (median, otherwise bounding-box)"),("ORIGIN_CURSOR","Origin to 3D Cursor","Move object origin to position of the 3D cursor"),("ORIGIN_CENTER_OF_MASS","Origin to Center of Mass (Surface)","Calculate the center of mass from the surface area"),("ORIGIN_CENTER_OF_VOLUME","Origin to Center of Mass (Volume)","Calculate the center of mass from the volume (must be manifold geometry with consistent normals)"),]),center=sn_cast_enum(r"MEDIAN", [("MEDIAN","Median Center",""),("BOUNDS","Bounds Center",""),]),)
    except Exception as exc:
        print(str(exc) + " | Error in function OBJECT FIX")

def physics_mesh_hullify():
    try:
        for_node_C9D4A = 0
        for_node_index_C9D4A = 0
        for for_node_index_C9D4A, for_node_C9D4A in enumerate(bonify_rigidbody["temp_phys_name"]):
            bpy.ops.object.select_all('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            run_function_on_5FB67 = bpy.data.objects[sn_cast_string(for_node_C9D4A)].select_set(state=True, view_layer=None, )
            bpy.context.view_layer.objects.active=bpy.data.objects[sn_cast_string(for_node_C9D4A)]
            bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
            bpy.ops.mesh.separate('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',type=sn_cast_enum(r"LOOSE", [("SELECTED","Selection",""),("MATERIAL","By Material",""),("LOOSE","By Loose Parts",""),]),)
            bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"OBJECT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
            bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
            bpy.ops.mesh.select_all('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            bpy.ops.mesh.convex_hull('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',delete_unused=True,use_existing_faces=True,make_holes=False,join_triangles=True,face_threshold=0.6981316804885864,shape_threshold=0.6981316804885864,uvs=False,vcols=False,seam=False,sharp=False,materials=False,)
            bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"OBJECT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
            bpy.ops.object.join('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',)
            bpy.ops.object.shade_smooth('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',)
            bpy.ops.object.move_to_collection('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',collection_index=0,is_new=True,new_collection_name=sn_cast_blend_data(bpy.context.active_object).name,)
    except Exception as exc:
        print(str(exc) + " | Error in function physics_mesh_hullify")

def progress(low, high, message, ):
    try:
        if sn_cast_int(eval("(sn_cast_float(low)/sn_cast_float(high))*100.0")) != bonify_rigidbody["prev_value"]:
            print((sn_cast_string(message) + r" : " + sn_cast_string(sn_cast_int(eval("(sn_cast_float(low)/sn_cast_float(high))*100.0"))) + r"%"))
        else:
            pass
        bonify_rigidbody["prev_value"] = 1
    except Exception as exc:
        print(str(exc) + " | Error in function progress")

def armature_creator():
    try:
        bonify_rigidbody["temp_armature_list"] = []
        bonify_rigidbody["temp_length"] = -1
        bpy.ops.object.armature_add('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',radius=1.0,enter_editmode=True,align=sn_cast_enum(r"WORLD", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 0.0),rotation=(0.0, 0.0, 0.0),scale=(0.0, 0.0, 0.0),)
        bonify_rigidbody["temp_armature_list"].append(bpy.context.active_object.name)
        bpy.ops.armature.select_all('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
        bpy.ops.armature.delete('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',)
        for_node_C3EC3 = 0
        for_node_index_C3EC3 = 0
        for for_node_index_C3EC3, for_node_C3EC3 in enumerate(bonify_rigidbody["obj_name"]):
            function_return_E59ED = progress(for_node_index_C3EC3, len(bonify_rigidbody["obj_name"]), r"Bone generation", )
            bpy.context.scene.cursor.location = bpy.data.objects[sn_cast_string(for_node_C3EC3)].location
            bonify_rigidbody["temp_length"] = int((1.0 + sn_cast_float(bonify_rigidbody["temp_length"])))
            if bonify_rigidbody["temp_length"] >= bpy.context.scene.bonesplit:
                bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"OBJECT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
                bpy.ops.object.armature_add('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',radius=1.0,enter_editmode=True,align=sn_cast_enum(r"WORLD", [("WORLD","World","Align the new object to the world"),("VIEW","View","Align the new object to the view"),("CURSOR","3D Cursor","Use the 3D cursor orientation for the new object"),]),location=(0.0, 0.0, 0.0),rotation=(0.0, 0.0, 0.0),scale=(0.0, 0.0, 0.0),)
                bonify_rigidbody["temp_armature_list"].append(bpy.context.active_object.name)
                bpy.ops.armature.select_all('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',action=sn_cast_enum(r"SELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
                bpy.ops.armature.delete('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',)
                bpy.ops.armature.bone_primitive_add('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',name=sn_cast_string(for_node_C3EC3),)
                bonify_rigidbody["temp_length"] = 0
            else:
                bpy.ops.armature.bone_primitive_add('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',name=sn_cast_string(for_node_C3EC3),)
        print(r"ARMATURE GENERATION COMPLETE")
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"OBJECT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
    except Exception as exc:
        print(str(exc) + " | Error in function Armature Creator")

def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def vertex_group_generator():
    try:
        op_reset_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"EDIT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=True,)
        bpy.context.area.type = op_reset_context
        for_node_FCA1F = 0
        for_node_index_FCA1F = 0
        for for_node_index_FCA1F, for_node_FCA1F in enumerate(bonify_rigidbody["obj_name"]):
            function_return_749EA = progress(for_node_index_FCA1F, len(bonify_rigidbody["obj_name"]), r"VertexGroup generation", )
            bpy.context.view_layer.objects.active=bpy.data.objects[sn_cast_string(for_node_FCA1F)]
            if len(sn_cast_list(bpy.data.objects[sn_cast_string(for_node_FCA1F)].vertex_groups)) != 0:
                bpy.ops.object.vertex_group_remove('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',all=True,all_unlocked=False,)
            else:
                pass
            try: exec((r"bpy.data.objects['" + sn_cast_string(for_node_FCA1F) + r"']" + r".vertex_groups.new( name = '" + sn_cast_string(for_node_FCA1F) + r"')"))
            except Exception as exc: sn_handle_script_line_exception(exc, (r"bpy.data.objects['" + sn_cast_string(for_node_FCA1F) + r"']" + r".vertex_groups.new( name = '" + sn_cast_string(for_node_FCA1F) + r"')"))
            bpy.ops.object.mode_set('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',mode=sn_cast_enum(r"OBJECT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
            bonify_rigidbody["vertex_length"] = []
            for_node_0B4B7 = 0
            for_node_index_0B4B7 = 0
            for for_node_index_0B4B7, for_node_0B4B7 in enumerate(sn_cast_list(bpy.context.active_object.data.vertices)):
                bonify_rigidbody["vertex_length"].append(for_node_index_0B4B7)
            try: exec((r"bpy.data.objects['" + sn_cast_string(for_node_FCA1F) + r"']" + r".vertex_groups['" + sn_cast_string(for_node_FCA1F) + r"'].add(" + sn_cast_string(bonify_rigidbody["vertex_length"]) + r", 1.0, 'REPLACE' )"))
            except Exception as exc: sn_handle_script_line_exception(exc, (r"bpy.data.objects['" + sn_cast_string(for_node_FCA1F) + r"']" + r".vertex_groups['" + sn_cast_string(for_node_FCA1F) + r"'].add(" + sn_cast_string(bonify_rigidbody["vertex_length"]) + r", 1.0, 'REPLACE' )"))
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"OBJECT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
    except Exception as exc:
        print(str(exc) + " | Error in function Vertex Group generator")

def mesh_matcher():
    try:
        bonify_rigidbody["temp_phys_name"] = []
        bpy.context.scene.frame_current = 0
        for_node_7330D = 0
        for_node_index_7330D = 0
        for for_node_index_7330D, for_node_7330D in enumerate(bpy.data.objects):
            run_function_on_22AFB = for_node_7330D.select_set(state=for_node_7330D.type=="ARMATURE", view_layer=None, )
        bpy.ops.object.mode_set('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',mode=sn_cast_enum(r"OBJECT", [("OBJECT","Object Mode",""),("EDIT","Edit Mode",""),("POSE","Pose Mode",""),("SCULPT","Sculpt Mode",""),("VERTEX_PAINT","Vertex Paint",""),("WEIGHT_PAINT","Weight Paint",""),("TEXTURE_PAINT","Texture Paint",""),("PARTICLE_EDIT","Particle Edit",""),("EDIT_GPENCIL","Edit Mode","Edit Grease Pencil Strokes"),("SCULPT_GPENCIL","Sculpt Mode","Sculpt Grease Pencil Strokes"),("PAINT_GPENCIL","Draw","Paint Grease Pencil Strokes"),("VERTEX_GPENCIL","Vertex Paint","Grease Pencil Vertex Paint Strokes"),("WEIGHT_GPENCIL","Weight Paint","Grease Pencil Weight Paint Strokes"),]),toggle=False,)
        print(r"MESH SPLIT START")
        for_node_98B02 = 0
        for_node_index_98B02 = 0
        for for_node_index_98B02, for_node_98B02 in enumerate(bpy.context.selected_objects):
            bonify_rigidbody["temp_bonenames"] = []
            for_node_7AC87 = 0
            for_node_index_7AC87 = 0
            for for_node_index_7AC87, for_node_7AC87 in enumerate(for_node_98B02.data.bones):
                bonify_rigidbody["temp_bonenames"].append(for_node_7AC87.name)
            bpy.ops.object.select_all('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',action=sn_cast_enum(r"DESELECT", [("TOGGLE","Toggle","Toggle selection for all elements"),("SELECT","Select","Select all elements"),("DESELECT","Deselect","Deselect all elements"),("INVERT","Invert","Invert selection of all elements"),]),)
            print(r"DESELECT COMP")
            bpy.context.view_layer.objects.active=bpy.data.objects[sn_cast_string(bonify_rigidbody["temp_bonenames"][0])]
            for_node_9109D = 0
            for_node_index_9109D = 0
            for for_node_index_9109D, for_node_9109D in enumerate(bonify_rigidbody["temp_bonenames"]):
                run_function_on_DC301 = bpy.data.objects[sn_cast_string(for_node_9109D)].select_set(state=True, view_layer=None, )
            bpy.ops.object.join('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',)
            bpy.ops.object.transform_apply('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',location=True,rotation=True,scale=True,properties=False,)
            run_function_on_1497B = bpy.context.active_object.modifiers.new(name=r"AutoArmature", type=sn_cast_enum(r"ARMATURE", [("DATA_TRANSFER","Data Transfer","Transfer several types of data (vertex groups, UV maps, vertex colors, custom normals) from one mesh to another"),("MESH_CACHE","Mesh Cache","Deform the mesh using an external frame-by-frame vertex transform cache"),("MESH_SEQUENCE_CACHE","Mesh Sequence Cache","Deform the mesh or curve using an external mesh cache in Alembic format"),("NORMAL_EDIT","Normal Edit","Modify the direction of the surface normals"),("WEIGHTED_NORMAL","Weighted Normal","Modify the direction of the surface normals using a weighting method"),("UV_PROJECT","UV Project","Project the UV map coordinates from the negative Z axis of another object"),("UV_WARP","UV Warp","Transform the UV map using the difference between two objects"),("VERTEX_WEIGHT_EDIT","Vertex Weight Edit","Modify of the weights of a vertex group"),("VERTEX_WEIGHT_MIX","Vertex Weight Mix","Mix the weights of two vertex groups"),("VERTEX_WEIGHT_PROXIMITY","Vertex Weight Proximity","Set the vertex group weights based on the distance to another target object"),("ARRAY","Array","Create copies of the shape with offsets"),("BEVEL","Bevel","Generate sloped corners by adding geometry to the mesh's edges or vertices"),("BOOLEAN","Boolean","Use another shape to cut, combine or perform a difference operation"),("BUILD","Build","Cause the faces of the mesh object to appear or disappear one after the other over time"),("DECIMATE","Decimate","Reduce the geometry density"),("EDGE_SPLIT","Edge Split","Split away joined faces at the edges"),("MASK","Mask","Dynamically hide vertices based on a vertex group or armature"),("MIRROR","Mirror","Mirror along the local X, Y and/or Z axes, over the object origin"),("MESH_TO_VOLUME","Mesh to Volume",""),("MULTIRES","Multiresolution","Subdivide the mesh in a way that allows editing the higher subdivision levels"),("REMESH","Remesh","Generate new mesh topology based on the current shape"),("SCREW","Screw","Lathe around an axis, treating the input mesh as a profile"),("SKIN","Skin","Create a solid shape from vertices and edges, using the vertex radius to define the thickness"),("SOLIDIFY","Solidify"," Make the surface thick"),("SUBSURF","Subdivision Surface","Split the faces into smaller parts, giving it a smoother appearance"),("TRIANGULATE","Triangulate","Convert all polygons to triangles"),("VOLUME_TO_MESH","Volume to Mesh",""),("WELD","Weld","Find groups of vertices closer than dist and merges them together"),("WIREFRAME","Wireframe","Convert faces into thickened edges"),("ARMATURE","Armature","Deform the shape using an armature object"),("CAST","Cast","Shift the shape towards a predefined primitive"),("CURVE","Curve","Bend the mesh using a curve object"),("DISPLACE","Displace","Offset vertices based on a texture"),("HOOK","Hook","Deform specific points using another object"),("LAPLACIANDEFORM","Laplacian Deform","Deform based a series of anchor points"),("LATTICE","Lattice","Deform using the shape of a lattice object"),("MESH_DEFORM","Mesh Deform","Deform using a different mesh, which acts as a deformation cage"),("SHRINKWRAP","Shrinkwrap","Project the shape onto another object"),("SIMPLE_DEFORM","Simple Deform","Deform the shape by twisting, bending, tapering or stretching"),("SMOOTH","Smooth","Smooth the mesh by flattening the angles between adjacent faces"),("CORRECTIVE_SMOOTH","Smooth Corrective","Smooth the mesh while still preserving the volume"),("LAPLACIANSMOOTH","Smooth Laplacian","Reduce the noise on a mesh surface with minimal changes to its shape"),("SURFACE_DEFORM","Surface Deform","Transfer motion from another mesh"),("WARP","Warp","Warp parts of a mesh to a new location in a very flexible way thanks to 2 specified objects"),("WAVE","Wave","Adds a ripple-like motion to an object’s geometry"),("VOLUME_DISPLACE","Volume Displace","Deform volume based on noise or other vector fields"),("CLOTH","Cloth",""),("COLLISION","Collision",""),("DYNAMIC_PAINT","Dynamic Paint",""),("EXPLODE","Explode","Break apart the mesh faces and let them follow particles"),("FLUID","Fluid",""),("OCEAN","Ocean","Generate a moving ocean surface"),("PARTICLE_INSTANCE","Particle Instance",""),("PARTICLE_SYSTEM","Particle System","Spawn particles from the shape"),("SOFT_BODY","Soft Body",""),("SURFACE","Surface",""),("SIMULATION","Simulation",""),]), )
            run_function_on_1497B.object = sn_cast_blend_data(for_node_98B02)
            bpy.ops.object.move_to_collection('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',collection_index=0,is_new=True,new_collection_name=bpy.context.active_object.name,)
            run_function_on_B8E15 = bpy.data.collections[bpy.context.active_object.name].objects.link(object=sn_cast_blend_data(for_node_98B02), )
            bonify_rigidbody["temp_phys_name"].append((r"physics_" + bpy.context.active_object.name_full))
            if sn_cast_blend_data(bpy.context.scene).generatephys:
                function_return_575D9 = physics_mesh_gen()
            else:
                pass
    except Exception as exc:
        print(str(exc) + " | Error in function Mesh Matcher")

def rigidbody_activate():
    try:
        for_node_0A17A = 0
        for_node_index_0A17A = 0
        for for_node_index_0A17A, for_node_0A17A in enumerate(bonify_rigidbody["obj_name"]):
            run_function_on_E5273 = bpy.data.objects[sn_cast_string(for_node_0A17A)].select_set(state=bpy.data.objects[sn_cast_string(for_node_0A17A)].type=="MESH", view_layer=None, )
            if bpy.data.objects[sn_cast_string(for_node_0A17A)].type=="MESH":
                bpy.context.view_layer.objects.active=bpy.data.objects[sn_cast_string(for_node_0A17A)]
            else:
                pass
        bpy.ops.rigidbody.objects_add('INVOKE_DEFAULT' if False else 'EXEC_DEFAULT',)
    except Exception as exc:
        print(str(exc) + " | Error in function RIGIDBODY ACTIVATE")


###############   EVALUATED CODE
#######   Bonify_RigidBody
class SNA_OT_Run_Bake(bpy.types.Operator):
    bl_idname = "sna.run_bake"
    bl_label = "Run bake"
    bl_description = "This is just Blender's default animation bake tool. It's here for convenience"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return bonify_rigidbody["bonify_complete"]

    def execute(self, context):
        try:
            bpy.context.scene.rigidbody_world.enabled = True
            bpy.ops.nla.bake('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',frame_start=1,frame_end=250,step=1,only_selected=False,visual_keying=True,clear_constraints=True,clear_parents=True,use_current_action=True,bake_types={sn_cast_enum(r"POSE", [("POSE","Pose","Bake bones transformations"),("OBJECT","Object","Bake object transformations"),])},)
            bonify_rigidbody["bake_complete"] = True
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Run bake")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Run bake")
        return self.execute(context)


class SNA_OT_Generate(bpy.types.Operator):
    bl_idname = "sna.generate"
    bl_label = "GENERATE"
    bl_description = "Smart QC generation. Creates qc files in .smd export path. Requires a valid system path EX. C:/Users/R60D/Desktop/"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # QCGENERATOR.py Script Start
            import bpy
            import os
            smd_model = []
            smd_animation = []
            iteratorcount = 0
            basepath = bpy.data.scenes[0].vs['export_path'] # this is where the .qc gets generated
            modelpath = bpy.data.scenes[0].modelpath # this is the path name for your model 
            materialpath =  bpy.data.scenes[0].materialpath # this is the pathname for your materials folder
            materialpath2 =  bpy.data.scenes[0].materialpath2 # this is the second pathname for your materials folder
            surfaceprop = bpy.data.scenes[0].surfaceprop # material for prop kind of useless due to collisions being incredibly expensive to do
            defaultanimfolder = bpy.data.scenes[0].animfolder
            scale = bpy.data.scenes[0].scalex
            for collection in bpy.data.collections:
                if not "RigidBodyWorld" == collection.name:
                    if not "Collection" == collection.name:
                        collection.name = collection.name.replace(".", "_")
                        for object in collection.objects:
                            object.name = object.name.replace(".", "_")
                            if object.type == 'ARMATURE':
                                object.animation_data.action.name = object.animation_data.action.name.replace(".", "_")
            for collection in bpy.data.collections:
                if not "RigidBodyWorld" == collection.name:
                    if not "Collection" == collection.name:
                        if not "physics_" in collection.name:
                            smd_model.append(collection.name)
                            for object in collection.objects:
                                if object.type == 'ARMATURE':
                                    smd_animation.append(object.animation_data.action.name)
            try:
                os.mkdir(basepath)
            except:
                print("folder already exists")
            finally:          
                for mesh in smd_model:
                        open(f'{basepath}\{mesh}.qc',"w").close()
                        go = open(f'{basepath}\{mesh}.qc',"a")
                        go.write(f'$scale    "{scale}"\n')
                        go.write(f'$modelname    "{modelpath}\{mesh}.mdl"\n')
                        go.write(f'$body mybody    "{mesh}.smd"\n')
                        go.write(f'$surfaceprop    "{surfaceprop}"\n')
                        go.write(f'$cdmaterials    "{materialpath}"\n')
                        go.write(f'$cdmaterials    "{materialpath2}"\n')
                        go.write(f'$sequence idle "anims\{smd_animation[iteratorcount]}.smd" frame 0 0\n')
                        go.write(f'$sequence physics "{defaultanimfolder}\{smd_animation[iteratorcount]}.smd"\n')
                        if bpy.data.scenes[0].collisioncheck == False:
                            go.write(f'$collisionmodel   "physics_{mesh}.smd"'+" {$concave $maxconvexpieces 128}")
                        go.close()
                        iteratorcount += 1
                        print("added")
            pass # QCGENERATOR.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of GENERATE")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of GENERATE")
        return context.window_manager.invoke_confirm(self, event)


class SNA_OT_Mesh_Matcher(bpy.types.Operator):
    bl_idname = "sna.mesh_matcher"
    bl_label = "Mesh Matcher"
    bl_description = "This will merge the individual objects into one mesh and attach it to it's corresponding armature"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return bonify_rigidbody["bake_complete"]

    def execute(self, context):
        try:
            function_return_A348F = mesh_matcher()
            bpy.context.scene.rigidbody_world.enabled = False
            bonify_rigidbody["mesh_matcher_complete"] = True
            function_return_77EFB = deselect_exportables()
            if sn_cast_blend_data(bpy.context.scene).generatephys:
                function_return_82104 = physics_mesh_hullify()
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Mesh Matcher")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Mesh Matcher")
        return self.execute(context)


class SNA_OT_Set_Default_Qc_Values(bpy.types.Operator):
    bl_idname = "sna.set_default_qc_values"
    bl_label = "Set default QC values"
    bl_description = "Sets QC values to default"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            sn_cast_blend_data(bpy.context.scene).materialpath = r"models\physics"
            sn_cast_blend_data(bpy.context.scene)["materialpath2"] = r""
            sn_cast_blend_data(bpy.context.scene)["surfaceprop"] = r"combine_metal"
            sn_cast_blend_data(bpy.context.scene)["modelpath"] = r"physics\generated"
            sn_cast_blend_data(bpy.context.scene)["animfolder"] = r"anims"
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Set default QC values")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Set default QC values")
        return context.window_manager.invoke_confirm(self, event)


class SNA_PT_QC_Generate_657F7(bpy.types.Panel):
    bl_label = "QC Generate"
    bl_idname = "SNA_PT_QC_Generate_657F7"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = 'scene'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in QC Generate panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 2.0
            col.scale_y = 2.0
            split = col.split(align=False,factor=0.5)
            split.enabled = True
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.0
            op = split.operator("sna.generate",text=r"QC generator",emboss=True,depress=False,icon_value=0)
            op = split.operator("sna.set_default_qc_values",text=r"Defaults",emboss=True,depress=False,icon_value=0)
            col.prop(sn_cast_blend_data(bpy.context.scene),'materialpath',icon_value=0,text=r"$cdmaterials",emboss=True,)
            col.prop(sn_cast_blend_data(bpy.context.scene),'materialpath2',icon_value=0,text=r"$cdmaterials2",emboss=True,)
            col.prop(sn_cast_blend_data(bpy.context.scene),'surfaceprop',icon_value=0,text=r"$surfaceprop",emboss=True,)
            col.prop(sn_cast_blend_data(bpy.context.scene),'modelpath',icon_value=0,text=r"Model Path",emboss=True,)
            col.prop(sn_cast_blend_data(bpy.context.scene),'animfolder',icon_value=0,text=r"AnimFolder",emboss=True,)
            split = col.split(align=False,factor=0.4032258093357086)
            split.enabled = True
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.0
            split.prop(bpy.context.scene,'collisioncheck',icon_value=0,text=r"Collision",emboss=True,toggle=False,invert_checkbox=True,)
            split.prop(sn_cast_blend_data(bpy.context.scene),'scalex',text=r"Scale",emboss=True,slider=False,)
        except Exception as exc:
            print(str(exc) + " | Error in QC Generate panel")


class SNA_PT_Bonify_RigidBodies_1D523(bpy.types.Panel):
    bl_label = "Bonify (RigidBodies)"
    bl_idname = "SNA_PT_Bonify_RigidBodies_1D523"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = 'scene'
    bl_order = 66


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Bonify (RigidBodies) panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            split = col.split(align=False,factor=0.5)
            split.enabled = True
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.0
            op = split.operator("sna.bonifythis_may_take_a_while",text=r"Add bones to objects",emboss=True,depress=False,icon_value=0)
            split.prop(sn_cast_blend_data(bpy.context.scene),'bonesplit',text=r"SplitValue",emboss=False,slider=False,)
            op = col.operator("sna.run_bake",text=r"Bake",emboss=True,depress=False,icon_value=0)
            split = col.split(align=False,factor=0.5)
            split.enabled = True
            split.alert = False
            split.scale_x = 1.0
            split.scale_y = 1.0
            op = split.operator("sna.mesh_matcher",text=r"Smart Mesh merge",emboss=True,depress=False,icon_value=0)
            split.prop(sn_cast_blend_data(bpy.context.scene),'generatephys',icon_value=0,text=r"Make Separate collision hull",emboss=True,toggle=False,invert_checkbox=False,)
        except Exception as exc:
            print(str(exc) + " | Error in Bonify (RigidBodies) panel")


class SNA_OT_Bonifythis_May_Take_A_While(bpy.types.Operator):
    bl_idname = "sna.bonifythis_may_take_a_while"
    bl_label = "Bonify(This may take a while)"
    bl_description = "Smart tool for appending a bone to each object"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            bpy.ops.wm.console_toggle('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
            bpy.context.area.type=sn_cast_enum(r"VIEW_3D", [("EMPTY","Empty",""),("VIEW_3D","3D Viewport","Manipulate objects in a 3D environment"),("IMAGE_EDITOR","UV/Image Editor","View and edit images and UV Maps"),("NODE_EDITOR","Node Editor","Editor for node-based shading and compositing tools"),("SEQUENCE_EDITOR","Video Sequencer","Video editing tools"),("CLIP_EDITOR","Movie Clip Editor","Motion tracking tools"),("DOPESHEET_EDITOR","Dope Sheet","Adjust timing of keyframes"),("GRAPH_EDITOR","Graph Editor","Edit drivers and keyframe interpolation"),("NLA_EDITOR","Nonlinear Animation","Combine and layer Actions"),("TEXT_EDITOR","Text Editor","Edit scripts and in-file documentation"),("CONSOLE","Python Console","Interactive programmatic console for advanced editing and script development"),("INFO","Info","Log of operations, warnings and error messages"),("TOPBAR","Top Bar","Global bar at the top of the screen for global per-window settings"),("STATUSBAR","Status Bar","Global bar at the bottom of the screen for general status information"),("OUTLINER","Outliner","Overview of scene graph and all available data-blocks"),("PROPERTIES","Properties","Edit properties of active object and related data-blocks"),("FILE_BROWSER","File Browser","Browse for files and assets"),("PREFERENCES","Preferences","Edit persistent configuration settings"),])
            bpy.context.area.ui_type=bpy.context.area.ui_type
            function_return_07283 = store_obj_data()
            function_return_94DC1 = object_fix()
            function_return_03D49 = vertex_group_generator()
            function_return_B4545 = armature_creator()
            function_return_2C510 = bone_child_maker()
            function_return_5375E = rigid_detect()
            if bonify_rigidbody["add_rigidbody"]:
                function_return_5AC38 = rigidbody_activate()
            else:
                pass
            bonify_rigidbody["bonify_complete"] = True
            bpy.context.area.type=sn_cast_enum(r"PROPERTIES", [("EMPTY","Empty",""),("VIEW_3D","3D Viewport","Manipulate objects in a 3D environment"),("IMAGE_EDITOR","UV/Image Editor","View and edit images and UV Maps"),("NODE_EDITOR","Node Editor","Editor for node-based shading and compositing tools"),("SEQUENCE_EDITOR","Video Sequencer","Video editing tools"),("CLIP_EDITOR","Movie Clip Editor","Motion tracking tools"),("DOPESHEET_EDITOR","Dope Sheet","Adjust timing of keyframes"),("GRAPH_EDITOR","Graph Editor","Edit drivers and keyframe interpolation"),("NLA_EDITOR","Nonlinear Animation","Combine and layer Actions"),("TEXT_EDITOR","Text Editor","Edit scripts and in-file documentation"),("CONSOLE","Python Console","Interactive programmatic console for advanced editing and script development"),("INFO","Info","Log of operations, warnings and error messages"),("TOPBAR","Top Bar","Global bar at the top of the screen for global per-window settings"),("STATUSBAR","Status Bar","Global bar at the bottom of the screen for general status information"),("OUTLINER","Outliner","Overview of scene graph and all available data-blocks"),("PROPERTIES","Properties","Edit properties of active object and related data-blocks"),("FILE_BROWSER","File Browser","Browse for files and assets"),("PREFERENCES","Preferences","Edit persistent configuration settings"),])
            bpy.context.area.ui_type=bpy.context.area.ui_type
            bpy.ops.wm.console_toggle('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Bonify(This may take a while)")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Bonify(This may take a while)")
        return context.window_manager.invoke_confirm(self, event)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.bonify_rigidbody_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.bonify_rigidbody_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.bonify_rigidbody_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.bonesplit = bpy.props.IntProperty(name='BONESPLIT',description='Split Armatures in groups of this value. Lowering this value will fix crowbar issues like having too many vertices in one model. Type the value to override the 127 limit',subtype='NONE',options=set(),default=127,min=1,soft_min=1,soft_max=127)
    bpy.types.Scene.materialpath = bpy.props.StringProperty(name='MaterialPath',description='Material Path value for the models',subtype='NONE',options={'HIDDEN'},default='models\physics')
    bpy.types.Scene.surfaceprop = bpy.props.StringProperty(name='SurfaceProp',description='Surface prop value for the models',subtype='NONE',options={'HIDDEN'},default='combine_metal')
    bpy.types.Scene.modelpath = bpy.props.StringProperty(name='ModelPath',description='This is the folder path for $modelname. The model name comes from the collection name.',subtype='NONE',options={'HIDDEN'},default='physics\generated')
    bpy.types.Scene.collisioncheck = bpy.props.BoolProperty(name='CollisionCheck',description='Enables/Disables the collision parameter for the .QC generator',options=set(),default=True)
    bpy.types.Scene.animfolder = bpy.props.StringProperty(name='AnimFolder',description='The animation folder for all the sequences',subtype='NONE',options=set(),default='anims')
    bpy.types.Scene.materialpath2 = bpy.props.StringProperty(name='MaterialPath2',description='Secondary Material Path value for the models',subtype='NONE',options=set(),default='')
    bpy.types.Scene.temp_phys_name = bpy.props.StringProperty(name='temp_phys_name',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.generatephys = bpy.props.BoolProperty(name='GeneratePhys',description='Duplicates each mesh into a convex hull',options=set(),default=False)
    bpy.types.Scene.scalex = bpy.props.FloatProperty(name='ScaleX',description='$scale value for the .qcs',subtype='NONE',unit='NONE',options=set(),precision=3, default=1.0,min=0.0010000000474974513)

def sn_unregister_properties():
    del bpy.types.Scene.bonesplit
    del bpy.types.Scene.materialpath
    del bpy.types.Scene.surfaceprop
    del bpy.types.Scene.modelpath
    del bpy.types.Scene.collisioncheck
    del bpy.types.Scene.animfolder
    del bpy.types.Scene.materialpath2
    del bpy.types.Scene.temp_phys_name
    del bpy.types.Scene.generatephys
    del bpy.types.Scene.scalex


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Run_Bake)
    bpy.utils.register_class(SNA_OT_Generate)
    bpy.utils.register_class(SNA_OT_Mesh_Matcher)
    bpy.utils.register_class(SNA_OT_Set_Default_Qc_Values)
    bpy.utils.register_class(SNA_PT_QC_Generate_657F7)
    bpy.utils.register_class(SNA_PT_Bonify_RigidBodies_1D523)
    bpy.utils.register_class(SNA_OT_Bonifythis_May_Take_A_While)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.utils.unregister_class(SNA_OT_Bonifythis_May_Take_A_While)
    bpy.utils.unregister_class(SNA_PT_Bonify_RigidBodies_1D523)
    bpy.utils.unregister_class(SNA_PT_QC_Generate_657F7)
    bpy.utils.unregister_class(SNA_OT_Set_Default_Qc_Values)
    bpy.utils.unregister_class(SNA_OT_Mesh_Matcher)
    bpy.utils.unregister_class(SNA_OT_Generate)
    bpy.utils.unregister_class(SNA_OT_Run_Bake)