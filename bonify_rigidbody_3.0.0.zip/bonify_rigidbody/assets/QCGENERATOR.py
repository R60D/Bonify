import bpy
import os
smd_model = []
smd_animation = []
iteratorcount = 0

basepath = bpy.data.scenes[0].vs['export_path'] # this is where the .qc gets generated
modelpath = bpy.data.scenes[0].modelpath # this is the path name for your model 
materialpath =  bpy.data.scenes[0].materialpath # this is the pathname for your materials folder
materialpath2 =  bpy.data.scenes[0].materialpath2 # this is the second pathname for your materials folder
surfaceprop = bpy.data.scenes[0].surfaceprop # material for prop kind of useless due to collisions being incredibly expensive to do
defaultanimfolder = bpy.data.scenes[0].animfolder
scale = bpy.data.scenes[0].scalex


for collection in bpy.data.collections:
    if not "RigidBodyWorld" == collection.name:
        if not "Collection" == collection.name:
            collection.name = collection.name.replace(".", "_")
            for object in collection.objects:
                object.name = object.name.replace(".", "_")
                if object.type == 'ARMATURE':
                    object.animation_data.action.name = object.animation_data.action.name.replace(".", "_")


for collection in bpy.data.collections:
    if not "RigidBodyWorld" == collection.name:
        if not "Collection" == collection.name:
            if not "physics_" in collection.name:
                smd_model.append(collection.name)
                for object in collection.objects:
                    if object.type == 'ARMATURE':
                        smd_animation.append(object.animation_data.action.name)
                
try:
    os.mkdir(basepath)
except:
    print("folder already exists")
finally:          
    for mesh in smd_model:
            open(f'{basepath}\{mesh}.qc',"w").close()
            go = open(f'{basepath}\{mesh}.qc',"a")
            go.write(f'$scale    "{scale}"\n')
            go.write(f'$modelname    "{modelpath}\{mesh}.mdl"\n')
            go.write(f'$body mybody    "{mesh}.smd"\n')
            go.write(f'$surfaceprop    "{surfaceprop}"\n')
            go.write(f'$cdmaterials    "{materialpath}"\n')
            go.write(f'$cdmaterials    "{materialpath2}"\n')
            go.write(f'$sequence idle "anims\{smd_animation[iteratorcount]}.smd" frame 0 0\n')
            go.write(f'$sequence physics "{defaultanimfolder}\{smd_animation[iteratorcount]}.smd"\n')
            if bpy.data.scenes[0].collisioncheck == False:
                go.write(f'$collisionmodel   "physics_{mesh}.smd"'+" {$concave $maxconvexpieces 128}")
            go.close()
            iteratorcount += 1
            print("added")
